SOS_TOKEN = '<sos>'  # start of sentence token
EOS_TOKEN = '<eos>'  # end of sentence token
PAD_TOKEN = '<pad>'  # pad token
LSTM = 'LSTM'
GRU = 'GRU'
MODEL_FORMAT = "seq2seq-%d-%f-%f.pt"
MODEL_START_FORMAT = "seq2seq-%d"
